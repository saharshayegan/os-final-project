./shm-client `printf 'a%.0s' {1..100}`
./shm-client `printf 'a%.0s' {1..1024}`
./shm-client `printf 'a%.0s' {1..2048}`
./shm-client `printf 'a%.0s' {1..4096}`
./shm-client `printf 'a%.0s' {1..8192}`
