./socket-client -h 127.0.0.1 -p 5000 `printf 'a%.0s' {1..100}`
./socket-client -h 127.0.0.1 -p 5000 `printf 'a%.0s' {1..1024}`
./socket-client -h 127.0.0.1 -p 5000 `printf 'a%.0s' {1..2048}`
./socket-client -h 127.0.0.1 -p 5000 `printf 'a%.0s' {1..4096}`
./socket-client -h 127.0.0.1 -p 5000 `printf 'a%.0s' {1..8100}`
